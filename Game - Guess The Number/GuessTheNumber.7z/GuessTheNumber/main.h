#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "image.h"
#include "game.h"

int main();
int main_game();
int main_teste();


#endif // MAIN_H_INCLUDED
